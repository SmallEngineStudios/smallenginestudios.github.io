# Small Engine Studios — Audio Suite VST3 installer
# Copies the .vst3 bundles next to this script into the system VST3 folder,
# then tells you to rescan in your DAW. Run by double-clicking; it will ask
# for admin rights on its own (Program Files needs elevation).
#
# Manual alternative: copy the *.vst3 folders to
#   C:\Program Files\Common Files\VST3\
# yourself, then rescan plugins in FL Studio (Plugin Manager > Rescan).

$ErrorActionPreference = "Stop"

# --- Self-elevate -----------------------------------------------------------
$admin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    Write-Host "Requesting administrator rights..."
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

$dest = Join-Path $env:ProgramFiles "Common Files\VST3"
if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest | Out-Null }

$here = Split-Path -Parent $PSCommandPath
$bundles = Get-ChildItem -Path $here -Directory -Filter "*.vst3"
if ($bundles.Count -eq 0) {
    Write-Host "No .vst3 bundles found next to this script. Nothing installed."
    Read-Host "Press Enter to close"
    exit 1
}

foreach ($b in $bundles) {
    $target = Join-Path $dest $b.Name
    if (Test-Path $target) { Remove-Item -Recurse -Force $target }
    Copy-Item -Recurse -Force $b.FullName $target
    Write-Host "Installed: $($b.Name)"
}

Write-Host ""
Write-Host "Done. In FL Studio: Options > Manage plugins > Rescan (verify new)."
Write-Host "Look for SQUEEZE, SHAPE, EMBER, SPACE, ECHO, CEILING."
Read-Host "Press Enter to close"
