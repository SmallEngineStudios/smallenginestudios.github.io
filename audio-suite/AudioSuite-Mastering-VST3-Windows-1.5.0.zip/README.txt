Mastering Suite VST3 Plugins for Windows (64-bit) — v1.5.0
===============================================================
Small Engine Studios — five mastering plugins for FL Studio (and any VST3 host):
SCULPT (surgical EQ), GLUE (multiband compression), WIDTH (stereo imaging),
SHEEN (harmonic exciter), LOUD (maximizer).

INSTALL (pick one):
  A) Double-click Install-AudioSuite.ps1 (asks for admin, copies everything).
  B) Manually copy the *.vst3 folders to:
       C:\Program Files\Common Files\VST3Then in FL Studio: Options > Manage plugins > Rescan (verify new).

CHECK FOR UPDATES: each plugin shows its version (bottom-right of the
window) and tells you when a newer build is available — one click opens
the download page. Or check:
  https://smallenginestudios.github.io/audio-suite/version.json
