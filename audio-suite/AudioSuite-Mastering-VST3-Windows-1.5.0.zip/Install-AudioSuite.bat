@echo off
rem Small Engine Studios — Audio Suite VST3 installer launcher.
rem Windows opens .ps1 files in Notepad on double-click, so this wrapper
rem runs the real installer (Install-AudioSuite.ps1) with the right flags.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AudioSuite.ps1"
